cd /home/dnascript/Desktop/ThermalCamera_standalone
python3 GUI.py 
